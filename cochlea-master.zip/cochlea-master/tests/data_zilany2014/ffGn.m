function y = ffGn(N, tdres, Hinput, noiseType, mu, sigma)

warning('Using fake ffGn().')

y = zeros(1,N);
