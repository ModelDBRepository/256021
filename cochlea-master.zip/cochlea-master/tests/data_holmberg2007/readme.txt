Test data for run_holmberg2007 in holmberg2007.npz is not based on the
original C/MATLAB model.  It was generated with one of the first
versions wrapped in Python and DSAM substitutes.  As far as I
remember, I have verified the first Python/C version against the
original.
