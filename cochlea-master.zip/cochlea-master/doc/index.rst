***********************************
Welcome to cochlea's documentation!
***********************************

.. module:: cochlea
   :synopsis: Inner ear models in Python
.. moduleauthor:: Marek Rudnicki


The module is available at https://github.com/mrkrd/cochlea



.. toctree::
   :maxdepth: 2

   api




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
