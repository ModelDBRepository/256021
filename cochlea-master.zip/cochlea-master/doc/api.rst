


.. toctree::
   :maxdepth: 2


API
===

cochlea
-------

.. automodule:: cochlea
   :members:
   :imported-members:



cochlea.external
----------------

.. automodule:: cochlea.external
   :members:
   :imported-members:





cochlea.stats
----------------

.. automodule:: cochlea.stats
   :members:
   :imported-members:
