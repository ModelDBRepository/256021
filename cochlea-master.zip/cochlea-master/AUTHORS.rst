Authors and Contributors
========================

* Marek Rudnicki <marekrud@posteo.com>
* Werner Hemmert <werner.hemmert@tum.de>
* Marcus Holmberg
* Muhammad S. A. Zilany
* Ian C. Bruce
* Laurel H. Carney
* Jörg Encke
* Kenji Noguchi
