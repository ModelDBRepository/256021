#include <math.h>
#include <stdlib.h>

#define SECTIONS 100


double ihcrp_init_c(double f_s);
void ihcrp_c(double *uIHC, double *xBM, double *ciliaCouplingGain);

