
Examples
========


Contents:

.. toctree::
    :maxdepth: 0

    examples/test_circuit
    examples/test_mechanisms
    examples/test_an_model
    examples/test_bushy_variation
    examples/test_simple_synapses
    examples/test_mso_inputs
    examples/test_sgc_input_phaselocking
    examples/test_populations
    examples/test_sgc_input
    examples/test_cells
    examples/test_physiology
    examples/figures
    examples/test_ccstim
    examples/test_sounds
    examples/toy_model
    examples/test_sound_stim
    examples/test_sgc_input_PSTH
    examples/test_synapses
    examples/test_decorator
    examples/plot_hcno_kinetics
    examples/play_test_sounds
