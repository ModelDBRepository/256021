cnmodel.populations package
---------------------------


.. automodule:: cnmodel.populations
    :members:
    :undoc-members:
    :show-inheritance:


cnmodel.populations.population
===============================

.. automodule:: cnmodel.populations.population
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:
    
cnmodel.populations.bushy
=========================

.. automodule:: cnmodel.populations.bushy
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:

cnmodel.populations.dstellate
=============================

.. automodule:: cnmodel.populations.dstellate
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:

cnmodel.populations.sgc
=======================

.. automodule:: cnmodel.populations.sgc
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:
    
cnmodel.populations.tstellate
=============================

.. automodule:: cnmodel.populations.tstellate
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:
