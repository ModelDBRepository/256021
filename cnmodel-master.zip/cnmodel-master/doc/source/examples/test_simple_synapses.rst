
examples.test_simple_synapses
-----------------------------

.. automodule:: examples.test_simple_synapses
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:

