
examples.test_an_model
----------------------

.. automodule:: examples.test_an_model
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:

