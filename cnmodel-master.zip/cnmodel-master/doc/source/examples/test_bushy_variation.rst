
examples.test_bushy_variation
-----------------------------

.. automodule:: examples.test_bushy_variation
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:

