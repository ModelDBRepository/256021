
examples.test_synapses
----------------------

.. automodule:: examples.test_synapses
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:

