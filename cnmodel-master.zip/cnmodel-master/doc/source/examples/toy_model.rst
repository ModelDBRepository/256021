
examples.toy_model
------------------

.. automodule:: examples.toy_model
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:

