.. CNModel documentation master file, created by
   sphinx-quickstart on Sun Apr  2 15:20:59 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to CNModel's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   architecture

.. toctree::
   :maxdepth: 1
   
   examples
   modules

Indices and tables
==================

* :ref:`modindex`
* :ref:`genindex`
* :ref:`search`

.. automodule:: cnmodel
    :members:
    :show-inheritance:
    :undoc-members: