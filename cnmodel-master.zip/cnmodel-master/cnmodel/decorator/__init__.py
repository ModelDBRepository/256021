#!/usr/bin/python
#
# Channel decorator class for cnmodel
#
# Paul B. Manis, Ph.D. January 2016
#
from neuron import h

from .decorator import Decorator
