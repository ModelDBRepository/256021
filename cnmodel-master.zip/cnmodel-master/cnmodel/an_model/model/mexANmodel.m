clear all;
mex -v model_IHC.c complex.c  
clear all;
mex -v model_Synapse.c complex.c 
