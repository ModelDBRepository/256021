from .DiffTreeWidget import DiffTreeWidget

